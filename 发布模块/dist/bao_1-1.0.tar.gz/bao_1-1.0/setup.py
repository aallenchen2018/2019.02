from distutils.core import setup

setup(name='bao_1',
    version='1.0',
    description='测试包模块',
    author='aallen',
    py_modules=['bao_1.send_message','bao_1.receive_message'])