def receive():
    print('正在接受message')